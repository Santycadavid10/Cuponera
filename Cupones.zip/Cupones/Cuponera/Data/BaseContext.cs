using Microsoft.EntityFrameworkCore;
using Cupones.Models;

namespace Cupones.Data;
public class CuponesContext : DbContext
{
    public CuponesContext(DbContextOptions<CuponesContext> options) : base(options)
    {
    }
    public DbSet<Cupon> Cupones { get; set; }
}